<!doctype html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="kb-skip" href="#main"><?php echo esc_html( kb_t( 'skip' ) ); ?></a>
<header class="kb-header">
	<div class="site-container kb-header__inner">
		<a class="kb-logo" href="<?php echo esc_url( function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' ) ); ?>"<?php echo is_front_page() ? ' aria-current="page"' : ''; ?>>Kiln<span>berry</span></a>
		<nav class="kb-nav" id="kb-nav" aria-label="<?php echo esc_attr( kb_t( 'nav' ) ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => 'primary',
				'container'      => false,
				'menu_class'     => 'kb-nav__list',
				'depth'          => 1,
				'fallback_cb'    => 'kb_menu_fallback',
			) );
			?>
		</nav>
		<div class="kb-controls">
			<?php kb_language_switch(); ?>
			<button class="kb-theme" type="button" data-kb-theme hidden>
				<span class="kb-theme__to-night"><?php echo kb_icon( 'moon' ); // phpcs:ignore WordPress.Security.EscapeOutput -- own SVG ?><span><?php echo esc_html( kb_t( 'night' ) ); ?></span></span>
				<span class="kb-theme__to-day"><?php echo kb_icon( 'sun' ); // phpcs:ignore ?><span><?php echo esc_html( kb_t( 'day' ) ); ?></span></span>
			</button>
			<button class="kb-burger" type="button" aria-expanded="false" aria-controls="kb-nav" aria-label="<?php echo esc_attr( kb_t( 'menu' ) ); ?>" data-kb-menu>
				<span class="kb-burger__open"><?php echo kb_icon( 'menu' ); // phpcs:ignore ?></span><span class="kb-burger__close"><?php echo kb_icon( 'x' ); // phpcs:ignore ?></span>
			</button>
		</div>
	</div>
</header>
