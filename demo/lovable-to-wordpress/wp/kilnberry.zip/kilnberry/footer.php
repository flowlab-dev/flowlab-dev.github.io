<footer class="kb-footer">
	<div class="site-container kb-footer__inner">
		<div>
			<a class="kb-logo" href="<?php echo esc_url( function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' ) ); ?>">Kiln<span>berry</span></a>
			<p class="kb-footer__hours"><?php echo esc_html( kb_studio( 'hours' ) ); ?></p>
			<p class="kb-footer__note"><?php echo esc_html( kb_studio( 'note' ) ); ?></p>
		</div>
		<nav class="kb-footer__nav" aria-label="<?php echo esc_attr( kb_t( 'footer_nav' ) ); ?>">
			<?php
			wp_nav_menu( array(
				'theme_location' => has_nav_menu( 'footer' ) ? 'footer' : 'primary',
				'container'      => false,
				'menu_class'     => 'kb-footer__list',
				'depth'          => 1,
				'fallback_cb'    => 'kb_menu_fallback',
			) );
			?>
		</nav>
	</div>
</footer>
<?php wp_footer(); ?>
</body>
</html>
