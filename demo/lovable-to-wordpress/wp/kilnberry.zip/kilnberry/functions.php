<?php
/**
 * Kilnberry — the Lovable site rebuilt as a classic WordPress theme. Each part lives in its own file in inc/.
 */

defined( 'ABSPATH' ) || exit;

define( 'KB_VERSION', '1.0.0' );
define( 'KB_DIR', get_template_directory() );

require KB_DIR . '/inc/i18n.php';    // interface strings EN / RU (page content itself is edited in the block editor)
require KB_DIR . '/inc/setup.php';   // theme support, menus, styles, fonts, day / night without a flash
require KB_DIR . '/inc/studio.php';  // phone, email, address and hours in Appearance → Customize → Studio details
require KB_DIR . '/inc/art.php';     // the pottery drawings and icons from the Lovable site
require KB_DIR . '/inc/classes.php'; // «Classes»: name, length, price, text — shown on Home and Classes from one place
require KB_DIR . '/inc/form.php';    // contact form → «Messages» in the admin + email
require KB_DIR . '/inc/seo.php';     // page title and description per page, redirects from the old Lovable addresses
