<?php
/** Fallback template: the same as page.php. */
get_header();
?>
<main id="main" class="kb-main">
	<?php
	while ( have_posts() ) :
		the_post();
		the_content();
	endwhile;
	?>
</main>
<?php
get_footer();
