<?php
/**
 * Theme support, menus, styles. Fonts (Lora, Manrope; SIL OFL) are served from the theme, not from Google.
 * Day / night: a tiny script in <head> sets the class before the page paints, so there is no flash.
 * Same rules as the Lovable site: ?theme=dark|light in the address, then the saved choice, then the system setting.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'html5', array( 'search-form', 'gallery', 'caption', 'style', 'script', 'navigation-widgets' ) );
	add_theme_support( 'responsive-embeds' );
	add_theme_support( 'editor-styles' );
	add_editor_style( array( 'assets/fonts.css', 'assets/main.css' ) );
	register_nav_menus( array(
		'primary' => 'Header menu',
		'footer'  => 'Footer menu',
	) );
} );

add_action( 'wp_enqueue_scripts', function () {
	$uri = get_template_directory_uri();
	wp_enqueue_style( 'kb-fonts', $uri . '/assets/fonts.css', array(), KB_VERSION );
	wp_enqueue_style( 'kb-main', $uri . '/assets/main.css', array( 'kb-fonts' ), KB_VERSION );
	wp_enqueue_script( 'kb-main', $uri . '/assets/main.js', array(), KB_VERSION, array( 'strategy' => 'defer', 'in_footer' => true ) );
	wp_localize_script( 'kb-main', 'KB', array(
		'day'      => kb_t( 'day' ),
		'night'    => kb_t( 'night' ),
		'toDay'    => kb_t( 'to_day' ),
		'toNight'  => kb_t( 'to_night' ),
		'menu'     => kb_t( 'menu' ),
		'close'    => kb_t( 'close' ),
		'eName'    => kb_t( 'e_name' ),
		'eEmail'   => kb_t( 'e_email' ),
		'eMsg'     => kb_t( 'e_msg' ),
		'eFail'    => kb_t( 'e_fail' ),
		'sending'  => kb_t( 'f_sending' ),
	) );
} );

// preload the two fonts of the first screen
add_action( 'wp_head', function () {
	$uri = get_template_directory_uri() . '/assets/fonts/';
	foreach ( array( 'Lora-latin.woff2', 'Manrope.woff2' ) as $f ) {
		printf( '<link rel="preload" href="%s" as="font" type="font/woff2" crossorigin>' . "\n", esc_url( $uri . $f ) );
	}
}, 1 );

add_action( 'wp_head', function () {
	?>
<script>document.documentElement.classList.add('js');(function(){try{var q=new URLSearchParams(location.search).get('theme'),s=null;try{s=localStorage.getItem('kilnberry-theme')}catch(e){}if(q==='dark'||q==='light'){s=q;try{localStorage.setItem('kilnberry-theme',q)}catch(e){}}var d=s==='dark'||(s!=='light'&&matchMedia('(prefers-color-scheme: dark)').matches);document.documentElement.classList.toggle('dark',d);document.documentElement.style.colorScheme=d?'dark':'light'}catch(e){}})();</script>
	<?php
}, 0 );

/** Menu fallback before menus are set: the pages in their order. */
function kb_menu_fallback( $args ) {
	$pages = get_pages( array( 'sort_column' => 'menu_order', 'lang' => kb_lang() ) );
	echo '<ul class="' . esc_attr( $args['menu_class'] ) . '">';
	foreach ( $pages as $p ) {
		printf( '<li class="menu-item%s"><a href="%s"%s>%s</a></li>', is_page( $p->ID ) ? ' current-menu-item' : '', esc_url( get_permalink( $p ) ), is_page( $p->ID ) ? ' aria-current="page"' : '', esc_html( $p->post_title ) );
	}
	echo '</ul>';
}

/** EN | RU switch: links to the same page in the other language (Polylang). */
function kb_language_switch() {
	if ( ! function_exists( 'pll_the_languages' ) ) {
		return;
	}
	$langs = pll_the_languages( array( 'raw' => 1, 'hide_if_no_translation' => 0 ) );
	if ( ! $langs ) {
		return;
	}
	echo '<nav class="kb-lang" aria-label="' . esc_attr( kb_t( 'lang' ) ) . '">';
	foreach ( $langs as $l ) {
		printf( '<a href="%s" hreflang="%s" lang="%s"%s>%s</a>', esc_url( $l['url'] ), esc_attr( $l['locale'] ? str_replace( '_', '-', $l['locale'] ) : $l['slug'] ), esc_attr( $l['slug'] ), $l['current_lang'] ? ' aria-current="true"' : '', esc_html( strtoupper( $l['slug'] ) ) );
	}
	echo '</nav>';
}

// Without theme.json WordPress wraps group content in an extra div (.wp-block-group__inner-container).
// The layout here is written for the block markup as saved, so the wrapper is left out.
remove_filter( 'render_block_core/group', 'wp_restore_group_inner_container', 10 );
