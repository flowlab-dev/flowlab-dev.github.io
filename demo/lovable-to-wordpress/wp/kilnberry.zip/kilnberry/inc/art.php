<?php
/**
 * Рисунки и иконки, перенесённые из сайта Lovable как есть (inline SVG, без файлов).
 * Иконки — Lucide (ISC). kb_art( 'vase' | 'bowl' | 'mug' ), kb_icon( 'phone' ).
 */

defined( 'ABSPATH' ) || exit;

function kb_art( $name ) {
	$art = array(
		'vase' => '<svg viewBox="0 0 180 220" aria-hidden="true"><path d="M66 18h48v35c0 11 27 28 31 65 5 46-15 80-55 80s-60-34-55-80c4-37 31-54 31-65V18Z" fill="currentColor"></path><path d="M63 44h54M46 100c26 13 61 13 88 0M40 132c30 12 69 12 100 0" stroke="var(--color-background)" stroke-width="6" fill="none" opacity=".4"></path></svg>',
		'bowl' => '<svg viewBox="0 0 180 150" aria-hidden="true"><path d="M22 52h136c-3 50-28 76-68 76S25 102 22 52Z" fill="currentColor"></path><path d="M38 74c17 11 87 11 104 0" fill="none" stroke="var(--color-background)" stroke-width="5" opacity=".42"></path><ellipse cx="90" cy="52" rx="68" ry="13" fill="var(--color-muted)"></ellipse></svg>',
		'mug' => '<svg viewBox="0 0 180 150" aria-hidden="true"><path d="M42 38h78v85H58c-9-16-15-49-16-85Z" fill="currentColor"></path><path d="M119 55c36-6 39 54 1 48" fill="none" stroke="currentColor" stroke-width="13"></path><path d="M51 68h62" stroke="var(--color-background)" stroke-width="5" opacity=".4"></path></svg>',
	);
	return isset( $art[ $name ] ) ? str_replace( '<svg ', '<svg class="kb-art kb-art--' . $name . '" focusable="false" ', $art[ $name ] ) : '';
}

function kb_icon( $name ) {
	$icons = array(
		'map-pin' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><path d="M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0"></path><circle cx="12" cy="10" r="3"></circle></svg>',
		'phone' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><path d="M13.832 16.568a1 1 0 0 0 1.213-.303l.355-.465A2 2 0 0 1 17 15h3a2 2 0 0 1 2 2v3a2 2 0 0 1-2 2A18 18 0 0 1 2 4a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3a2 2 0 0 1-.8 1.6l-.468.351a1 1 0 0 0-.292 1.233 14 14 0 0 0 6.392 6.384"></path></svg>',
		'mail' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><path d="m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7"></path><rect x="2" y="4" width="20" height="16" rx="2"></rect></svg>',
		'arrow-right' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><path d="M5 12h14"></path><path d="m12 5 7 7-7 7"></path></svg>',
		'moon' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><path d="M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401"></path></svg>',
		'menu' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><path d="M4 5h16"></path><path d="M4 12h16"></path><path d="M4 19h16"></path></svg>',
		'sun' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><circle cx="12" cy="12" r="4"></circle><path d="M12 2v2"></path><path d="M12 20v2"></path><path d="m4.93 4.93 1.41 1.41"></path><path d="m17.66 17.66 1.41 1.41"></path><path d="M2 12h2"></path><path d="M20 12h2"></path><path d="m6.34 17.66-1.41 1.41"></path><path d="m19.07 4.93-1.41 1.41"></path></svg>',
		'x' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><path d="M18 6 6 18"></path><path d="m6 6 12 12"></path></svg>',
		'chevron-down' => '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="kb-icon" aria-hidden="true"><path d="m6 9 6 6 6-6"></path></svg>',
	);
	return isset( $icons[ $name ] ) ? $icons[ $name ] : '';
}

/** [kb_art name="vase,bowl" class="kb-scene"] — рисунок для блока «Шорткод» в редакторе. */
add_shortcode( 'kb_art', function ( $atts ) {
	$atts = shortcode_atts( array( 'name' => 'vase,bowl', 'class' => 'kb-scene' ), $atts );
	$out  = '';
	foreach ( array_map( 'trim', explode( ',', $atts['name'] ) ) as $n ) {
		$out .= kb_art( $n );
	}
	return '<div class="' . esc_attr( $atts['class'] ) . '" aria-hidden="true">' . $out . ( 'kb-scene' === $atts['class'] ? '<span class="kb-sun"></span>' : '' ) . '</div>';
} );
