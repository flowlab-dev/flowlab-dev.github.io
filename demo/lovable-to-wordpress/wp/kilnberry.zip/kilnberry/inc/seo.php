<?php
/**
 * Search appearance per page: the browser title and the description, carried over word for word from the Lovable site.
 * Edited in the «Search appearance» box under the page. Stays quiet if Yoast SEO or Rank Math is installed.
 * Old addresses: Lovable used one address per page and ?lang=ru for Russian. WordPress gives Russian pages their own
 * addresses (/ru/…), so /classes?lang=ru is sent to the Russian page with a permanent (301) redirect;
 * /classes → /classes/ is done by WordPress itself.
 */

defined( 'ABSPATH' ) || exit;

function kb_seo_plugin() {
	return defined( 'WPSEO_VERSION' ) || defined( 'RANK_MATH_VERSION' );
}

add_action( 'init', function () {
	foreach ( array( 'kb_seo_title', 'kb_seo_desc' ) as $key ) {
		register_post_meta( 'page', $key, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'sanitize_callback' => 'sanitize_text_field', 'auth_callback' => function () { return current_user_can( 'edit_pages' ); } ) );
	}
} );

add_action( 'add_meta_boxes_page', function () {
	if ( kb_seo_plugin() ) {
		return;
	}
	add_meta_box( 'kb_seo', 'Search appearance', function ( $post ) {
		wp_nonce_field( 'kb_seo', 'kb_seo_nonce' );
		printf( '<p><label for="kb_seo_title"><strong>Title in Google and the browser tab</strong></label><input class="widefat" id="kb_seo_title" name="kb_seo_title" maxlength="70" value="%s"></p>', esc_attr( get_post_meta( $post->ID, 'kb_seo_title', true ) ) );
		printf( '<p><label for="kb_seo_desc"><strong>Description in Google</strong> (up to ~160 characters)</label><textarea class="widefat" id="kb_seo_desc" name="kb_seo_desc" rows="3" maxlength="300">%s</textarea></p>', esc_textarea( get_post_meta( $post->ID, 'kb_seo_desc', true ) ) );
	}, 'page', 'normal', 'low' );
} );

add_action( 'save_post_page', function ( $id ) {
	if ( ! isset( $_POST['kb_seo_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kb_seo_nonce'] ) ), 'kb_seo' ) || ! current_user_can( 'edit_page', $id ) ) {
		return;
	}
	update_post_meta( $id, 'kb_seo_title', sanitize_text_field( wp_unslash( $_POST['kb_seo_title'] ?? '' ) ) );
	update_post_meta( $id, 'kb_seo_desc', sanitize_textarea_field( wp_unslash( $_POST['kb_seo_desc'] ?? '' ) ) );
} );

add_filter( 'pre_get_document_title', function ( $title ) {
	if ( kb_seo_plugin() ) {
		return $title;
	}
	if ( is_404() ) {
		return kb_t( 'not_found' ) . ' | Kilnberry';
	}
	$id = is_singular( 'page' ) ? get_queried_object_id() : 0;
	$t  = $id ? get_post_meta( $id, 'kb_seo_title', true ) : '';
	return $t ?: $title;
} );

add_action( 'wp_head', function () {
	if ( kb_seo_plugin() ) {
		return;
	}
	if ( is_404() ) { // as on the Lovable site
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( kb_t( 'not_found_desc' ) ) );
		return;
	}
	if ( ! is_singular( 'page' ) ) {
		return;
	}
	$id    = get_queried_object_id();
	$desc  = get_post_meta( $id, 'kb_seo_desc', true );
	$title = get_post_meta( $id, 'kb_seo_title', true ) ?: get_the_title( $id );
	if ( $desc ) {
		printf( '<meta name="description" content="%s">' . "\n", esc_attr( $desc ) );
		printf( '<meta property="og:description" content="%s">' . "\n", esc_attr( $desc ) );
	}
	printf( '<meta property="og:title" content="%s">' . "\n", esc_attr( $title ) );
	printf( '<meta property="og:type" content="website">' . "\n" . '<meta property="og:url" content="%s">' . "\n", esc_url( get_permalink( $id ) ) );
	printf( '<meta property="og:site_name" content="%s">' . "\n", esc_attr( get_bloginfo( 'name' ) ) );
	printf( '<meta property="og:locale" content="%s">' . "\n", 'ru' === kb_lang() ? 'ru_RU' : 'en_US' );
}, 2 );

/** Old Lovable link with ?lang=xx → the same page in that language, 301. Runs before Polylang reads ?lang. */
add_action( 'template_redirect', function () {
	if ( ! isset( $_GET['lang'] ) || ! function_exists( 'pll_get_post' ) || is_admin() ) {
		return;
	}
	$want = sanitize_key( $_GET['lang'] );
	if ( ! in_array( $want, array( 'en', 'ru' ), true ) ) {
		return;
	}
	$path = trim( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '', PHP_URL_PATH ), '/' );
	$base = trim( (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH ), '/' );
	if ( $base && str_starts_with( $path, $base ) ) {
		$path = trim( substr( $path, strlen( $base ) ), '/' );
	}
	$path = preg_replace( '#^(en|ru)(/|$)#', '', $path );
	$page = '' === $path ? (int) get_option( 'page_on_front' ) : ( get_page_by_path( $path )->ID ?? 0 );
	$to   = $page ? pll_get_post( $page, $want ) : 0;
	if ( ! $to ) {
		return;
	}
	$url = get_permalink( $to );
	if ( isset( $_GET['theme'] ) && in_array( $_GET['theme'], array( 'dark', 'light' ), true ) ) {
		$url = add_query_arg( 'theme', sanitize_key( $_GET['theme'] ), $url );
	}
	wp_safe_redirect( $url, 301 );
	exit;
}, 0 );
