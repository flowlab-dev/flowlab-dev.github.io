<?php
/**
 * Interface strings in English and Russian. The language comes from Polylang; without Polylang the site is English.
 * Page texts are not here: they live in the pages themselves and are edited in the block editor.
 */

defined( 'ABSPATH' ) || exit;

/** Current language: en or ru. kb_lang( 'ru' ) fixes it for the rest of the request (the form handler has no page). */
function kb_lang( $set = null ) {
	static $forced = null;
	if ( $set ) {
		$forced = 'ru' === $set ? 'ru' : 'en';
	}
	if ( $forced ) {
		return $forced;
	}
	$lang = function_exists( 'pll_current_language' ) ? pll_current_language( 'slug' ) : '';
	return 'ru' === $lang ? 'ru' : 'en';
}

function kb_t( $key ) {
	static $d = array(
		'en' => array(
			'skip'        => 'Skip to content',
			'menu'        => 'Menu',
			'close'       => 'Close menu',
			'nav'         => 'Main',
			'footer_nav'  => 'Footer',
			'lang'        => 'Language',
			'day'         => 'Day',
			'night'       => 'Night',
			'to_day'      => 'Day: switch to the light theme',
			'to_night'    => 'Night: switch to the dark theme',
			'home'        => 'Home',
			'not_found'   => 'Page not found',
			'not_found_desc' => 'Small pottery classes in Southeast Portland.',
			'back_home'   => 'Back to home',
			'f_name'      => 'Name',
			'f_email'     => 'Email',
			'f_class'     => 'Which class?',
			'f_other'     => 'Something else',
			'f_msg'       => 'Message',
			'f_send'      => 'Send message',
			'f_sending'   => 'Sending…',
			'e_name'      => 'Please enter your name',
			'e_email'     => 'Please enter a valid email',
			'e_msg'       => 'Please write a message',
			'e_fail'      => 'Could not send. Check your connection and try again.',
			'e_stale'     => 'The page is out of date. Reload it and send again.',
			'e_many'      => 'Too many messages in a row. Please try again later.',
			'f_ok'        => 'Thank you. We have your message and will reply by email.',
			'f_label'     => 'Contact',
			'lead_title'  => 'Message',
		),
		'ru' => array(
			'skip'        => 'Перейти к содержанию',
			'menu'        => 'Меню',
			'close'       => 'Закрыть меню',
			'nav'         => 'Основное меню',
			'footer_nav'  => 'Меню в подвале',
			'lang'        => 'Язык',
			'day'         => 'День',
			'night'       => 'Ночь',
			'to_day'      => 'День: включить светлую тему',
			'to_night'    => 'Ночь: включить тёмную тему',
			'home'        => 'Главная',
			'not_found'   => 'Страница не найдена',
			'not_found_desc' => 'Небольшие занятия гончарным делом в юго-восточном Портленде.',
			'back_home'   => 'На главную',
			'f_name'      => 'Имя',
			'f_email'     => 'Эл. почта',
			'f_class'     => 'Какое занятие?',
			'f_other'     => 'Другое',
			'f_msg'       => 'Сообщение',
			'f_send'      => 'Отправить',
			'f_sending'   => 'Отправляем…',
			'e_name'      => 'Введите имя',
			'e_email'     => 'Введите правильный адрес почты',
			'e_msg'       => 'Напишите сообщение',
			'e_fail'      => 'Не получилось отправить. Проверьте интернет и попробуйте ещё раз.',
			'e_stale'     => 'Страница устарела. Обновите её и отправьте снова.',
			'e_many'      => 'Слишком много сообщений подряд. Попробуйте позже.',
			'f_ok'        => 'Спасибо. Сообщение получено, ответим на почту.',
			'f_label'     => 'Контакты',
			'lead_title'  => 'Сообщение',
		),
	);
	$lang = kb_lang();
	return $d[ $lang ][ $key ] ?? $d['en'][ $key ] ?? $key;
}
