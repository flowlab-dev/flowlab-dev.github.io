<?php
/**
 * Contact form [kb_form]: the message is saved in the admin («Messages», only administrators see it) and emailed.
 * On the Lovable site the form had no backend: it only said «thank you». Here messages are kept even if email fails.
 * Bots: a hidden field, a too-fast submit or more than 2 links → «thank you», nothing saved. Works without JavaScript too.
 * Recipient: define( 'KB_MESSAGES_EMAIL', 'studio@example.com' ) in wp-config.php, otherwise the admin email.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	register_post_type( 'kb_message', array(
		'labels'        => array( 'name' => 'Messages', 'singular_name' => 'Message' ),
		'public'        => false,
		'show_ui'       => true,
		'menu_icon'     => 'dashicons-email-alt',
		'menu_position' => 4,
		'supports'      => array( 'title', 'editor' ),
		// personal data: only site managers open it; messages are created only by the form
		'capabilities'  => array_merge(
			array_fill_keys( array( 'edit_post', 'read_post', 'delete_post', 'edit_posts', 'edit_others_posts', 'delete_posts', 'delete_others_posts', 'delete_private_posts', 'edit_private_posts', 'publish_posts', 'read_private_posts' ), 'manage_options' ),
			array( 'create_posts' => 'do_not_allow' )
		),
		'map_meta_cap'  => false,
	) );
} );

// messages are not translated
add_filter( 'pll_get_post_types', function ( $types ) {
	unset( $types['kb_message'] );
	return $types;
} );

add_shortcode( 'kb_form', function () {
	$sent    = isset( $_GET['kb_sent'] ) ? sanitize_key( $_GET['kb_sent'] ) : '';
	$classes = kb_get_classes();
	ob_start();
	if ( 'ok' === $sent ) {
		echo '<div class="kb-form__done" role="status" id="kb-form"><p>' . esc_html( kb_t( 'f_ok' ) ) . '</p></div>';
		return ob_get_clean();
	}
	?>
	<form class="kb-form" id="kb-form" method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" aria-label="<?php echo esc_attr( kb_t( 'f_label' ) ); ?>" data-kb-form data-ok="<?php echo esc_attr( kb_t( 'f_ok' ) ); ?>">
		<?php if ( 'err' === $sent ) : ?><p class="kb-form__alert" role="alert"><?php echo esc_html( kb_t( 'e_fail' ) ); ?></p><?php endif; ?>
		<input type="hidden" name="action" value="kb_message">
		<input type="hidden" name="kb_lang" value="<?php echo esc_attr( kb_lang() ); ?>">
		<input type="hidden" name="kb_back" value="<?php echo esc_url( get_permalink() ?: home_url( '/' ) ); ?>">
		<input type="hidden" name="kb_t" value="<?php echo esc_attr( time() ); ?>">
		<?php wp_nonce_field( 'kb_message', 'kb_nonce' ); ?>
		<div class="kb-form__hp" aria-hidden="true"><label>Website <input type="text" name="kb_website" tabindex="-1" autocomplete="off"></label></div>
		<label class="kb-field"><span><?php echo esc_html( kb_t( 'f_name' ) ); ?></span><input name="kb_name" maxlength="100" autocomplete="name" required aria-describedby="kb-e-name"><small class="kb-field__error" id="kb-e-name" hidden></small></label>
		<label class="kb-field"><span><?php echo esc_html( kb_t( 'f_email' ) ); ?></span><input name="kb_email" type="email" maxlength="255" autocomplete="email" required aria-describedby="kb-e-email"><small class="kb-field__error" id="kb-e-email" hidden></small></label>
		<label class="kb-field"><span><?php echo esc_html( kb_t( 'f_class' ) ); ?></span><select name="kb_class">
			<?php foreach ( $classes as $c ) : ?><option><?php echo esc_html( get_the_title( $c ) ); ?></option><?php endforeach; ?>
			<option><?php echo esc_html( kb_t( 'f_other' ) ); ?></option>
		</select></label>
		<label class="kb-field"><span><?php echo esc_html( kb_t( 'f_msg' ) ); ?></span><textarea name="kb_msg" rows="5" maxlength="2000" required aria-describedby="kb-e-msg"></textarea><small class="kb-field__error" id="kb-e-msg" hidden></small></label>
		<div><button class="kb-btn" type="submit"><?php echo esc_html( kb_t( 'f_send' ) ); ?></button></div>
		<p class="kb-form__status" role="status" aria-live="polite"></p>
	</form>
	<?php
	return ob_get_clean();
} );

add_action( 'admin_post_nopriv_kb_message', 'kb_handle_message' );
add_action( 'admin_post_kb_message', 'kb_handle_message' );

/** Answer: JSON for the JavaScript submit, otherwise back to the page with ?kb_sent=ok|err. */
function kb_handle_message() {
	$json = isset( $_SERVER['HTTP_ACCEPT'] ) && false !== strpos( sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT'] ) ), 'application/json' );
	$back = isset( $_POST['kb_back'] ) ? wp_validate_redirect( esc_url_raw( wp_unslash( $_POST['kb_back'] ) ), home_url( '/' ) ) : home_url( '/' );
	$f    = function ( $k, $max = 200 ) {
		return isset( $_POST[ $k ] ) ? mb_substr( trim( sanitize_textarea_field( wp_unslash( $_POST[ $k ] ) ) ), 0, $max ) : '';
	};
	$lang = 'ru' === $f( 'kb_lang', 2 ) ? 'ru' : 'en';
	kb_lang( $lang ); // answers in the language of the page the form was sent from
	$done = function ( $ok, $code = 200, $errors = array() ) use ( $json, $back ) {
		if ( $json ) {
			wp_send_json( array( 'ok' => $ok, 'errors' => $errors ), $code );
		}
		wp_safe_redirect( add_query_arg( 'kb_sent', $ok ? 'ok' : 'err', $back ) . '#kb-form', 303 );
		exit;
	};
	if ( ! isset( $_POST['kb_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kb_nonce'] ) ), 'kb_message' ) ) {
		$done( false, 403, array( 'form' => kb_t( 'e_stale' ) ) );
	}
	if ( '' !== $f( 'kb_website' ) || ( time() - (int) $f( 'kb_t', 12 ) ) < 3 || preg_match_all( '#https?://#i', $f( 'kb_msg', 2000 ) ) > 2 ) {
		$done( true );
	}

	$m = array(
		'name'  => sanitize_text_field( $f( 'kb_name', 100 ) ), // one line: it goes into the title
		'email' => sanitize_email( $f( 'kb_email', 255 ) ),
		'class' => $f( 'kb_class', 120 ),
		'msg'   => $f( 'kb_msg', 2000 ),
	);
	$errors = array();
	if ( '' === $m['name'] ) {
		$errors['kb_name'] = kb_t( 'e_name' );
	}
	if ( ! is_email( $m['email'] ) ) {
		$errors['kb_email'] = kb_t( 'e_email' );
	}
	if ( '' === $m['msg'] ) {
		$errors['kb_msg'] = kb_t( 'e_msg' );
	}
	if ( $errors ) {
		$done( false, 422, $errors );
	}

	// at most 5 messages in 10 minutes from one address (the address is kept only as a hash)
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$key = 'kb_rate_' . substr( hash_hmac( 'sha256', $ip, wp_salt() ), 0, 20 );
	$n   = (int) get_transient( $key );
	if ( $n >= 5 ) {
		$done( false, 429, array( 'form' => kb_t( 'e_many' ) ) );
	}
	set_transient( $key, $n + 1, 10 * MINUTE_IN_SECONDS );

	$title = 'Message from ' . $m['name'] . ( $m['class'] ? ' · ' . $m['class'] : '' );
	$body  = "Name: {$m['name']}\nEmail: {$m['email']}\nClass: {$m['class']}\nLanguage: " . strtoupper( $lang ) . "\n\n{$m['msg']}\n\nPage: {$back}";
	$id    = wp_insert_post( array( 'post_type' => 'kb_message', 'post_status' => 'private', 'post_title' => $title, 'post_content' => $body ), true );
	if ( is_wp_error( $id ) ) {
		$done( false, 500, array( 'form' => kb_t( 'e_fail' ) ) );
	}
	$to = defined( 'KB_MESSAGES_EMAIL' ) ? KB_MESSAGES_EMAIL : get_option( 'admin_email' );
	update_post_meta( $id, 'kb_mailed', wp_mail( $to, $title, $body, array( 'Reply-To: ' . $m['email'] ) ) ? 1 : 0 );
	$done( true );
}
