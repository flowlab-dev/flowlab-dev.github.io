<?php
/**
 * «Classes»: each class is one entry with a name, length, price and a short text (Classes → Edit).
 * The Home page shows the first three, the Classes page shows all of them, both from the same entries:
 * a price changed once is right everywhere. Order: the «Order» field. Translations: Polylang, like pages.
 */

defined( 'ABSPATH' ) || exit;

add_action( 'init', function () {
	register_post_type( 'kb_class', array(
		'labels'       => array(
			'name'          => 'Classes',
			'singular_name' => 'Class',
			'add_new_item'  => 'Add class',
			'edit_item'     => 'Edit class',
		),
		'public'       => false,
		'show_ui'      => true,
		'show_in_rest' => true,
		'menu_icon'    => 'dashicons-art',
		'menu_position' => 21,
		'supports'     => array( 'title', 'excerpt', 'page-attributes' ),
	) );
	foreach ( array( 'kb_length', 'kb_price' ) as $key ) {
		register_post_meta( 'kb_class', $key, array( 'type' => 'string', 'single' => true, 'show_in_rest' => true, 'sanitize_callback' => 'sanitize_text_field', 'auth_callback' => function () { return current_user_can( 'edit_posts' ); } ) );
	}
} );

// Polylang: classes are translated like pages
add_filter( 'pll_get_post_types', function ( $types ) {
	$types['kb_class'] = 'kb_class';
	return $types;
} );

// «Length» and «Price» fields under the title; the short text is the «Excerpt» box
add_action( 'add_meta_boxes_kb_class', function () {
	add_meta_box( 'kb_class_facts', 'Length and price', function ( $post ) {
		wp_nonce_field( 'kb_class', 'kb_class_nonce' );
		foreach ( array( 'kb_length' => 'Length (e.g. «2 hours»)', 'kb_price' => 'Price (e.g. «$45» or «from $300»)' ) as $key => $label ) {
			printf( '<p><label for="%1$s"><strong>%2$s</strong></label><br><input class="widefat" id="%1$s" name="%1$s" value="%3$s"></p>', esc_attr( $key ), esc_html( $label ), esc_attr( get_post_meta( $post->ID, $key, true ) ) );
		}
	}, 'kb_class', 'normal', 'high' );
} );

add_action( 'save_post_kb_class', function ( $id ) {
	if ( ! isset( $_POST['kb_class_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['kb_class_nonce'] ) ), 'kb_class' ) || ! current_user_can( 'edit_post', $id ) ) {
		return;
	}
	foreach ( array( 'kb_length', 'kb_price' ) as $key ) {
		if ( isset( $_POST[ $key ] ) ) {
			update_post_meta( $id, $key, sanitize_text_field( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
} );

add_filter( 'manage_kb_class_posts_columns', function ( $cols ) {
	return array_slice( $cols, 0, 2 ) + array( 'kb_price' => 'Price', 'kb_length' => 'Length' ) + $cols;
} );
add_action( 'manage_kb_class_posts_custom_column', function ( $col, $id ) {
	if ( in_array( $col, array( 'kb_price', 'kb_length' ), true ) ) {
		echo esc_html( get_post_meta( $id, $col, true ) );
	}
}, 10, 2 );

function kb_get_classes( $limit = -1 ) {
	$args = array( 'post_type' => 'kb_class', 'posts_per_page' => $limit, 'orderby' => array( 'menu_order' => 'ASC', 'ID' => 'ASC' ), 'no_found_rows' => true );
	if ( function_exists( 'pll_current_language' ) ) {
		$args['lang'] = kb_lang();
	}
	return get_posts( $args );
}

/** [kb_classes limit="3"] — class cards; without limit, all classes. */
add_shortcode( 'kb_classes', function ( $atts ) {
	$atts    = shortcode_atts( array( 'limit' => -1 ), $atts );
	$classes = kb_get_classes( (int) $atts['limit'] );
	if ( ! $classes ) {
		return '';
	}
	$out = '<div class="kb-classes' . ( (int) $atts['limit'] > 0 ? ' kb-classes--three' : '' ) . '">';
	foreach ( $classes as $c ) {
		$out .= sprintf(
			'<article class="kb-card kb-reveal"><div class="kb-card__top"><h3>%s</h3><p class="kb-card__price">%s</p></div><p class="kb-card__length">%s</p><p class="kb-card__text">%s</p></article>',
			esc_html( get_the_title( $c ) ),
			esc_html( get_post_meta( $c->ID, 'kb_price', true ) ),
			esc_html( get_post_meta( $c->ID, 'kb_length', true ) ),
			esc_html( $c->post_excerpt )
		);
	}
	return $out . '</div>';
} );
