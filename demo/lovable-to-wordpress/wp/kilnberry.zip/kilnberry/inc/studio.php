<?php
/**
 * Studio details in Appearance → Customize → Studio details: change once, used in the footer and on the Contact page.
 * Address and hours have an English and a Russian field. Phone 555-01xx and the .example email are fictional on purpose.
 */

defined( 'ABSPATH' ) || exit;

function kb_studio_defaults() {
	return array(
		'kb_phone'      => '(503) 555-0142',
		'kb_email'      => 'hello@kilnberry.example',
		'kb_address_en' => 'Southeast Portland, Oregon',
		'kb_address_ru' => 'Юго-восточный Портленд, Орегон',
		'kb_hours_en'   => 'Tue–Fri 10:00–21:00 · Sat–Sun 10:00–18:00 · Mon closed',
		'kb_hours_ru'   => 'Вт–пт 10:00–21:00 · сб–вс 10:00–18:00 · пн выходной',
		'kb_note_en'    => 'Demo site. Kilnberry Clay Studio is a fictional business.',
		'kb_note_ru'    => 'Демо-сайт. Студия Kilnberry Clay Studio вымышленная.',
	);
}

/** kb_studio( 'hours' ) → the value for the current language; kb_studio( 'phone' ) → the shared value. */
function kb_studio( $key ) {
	$d    = kb_studio_defaults();
	$name = isset( $d[ 'kb_' . $key ] ) ? 'kb_' . $key : 'kb_' . $key . '_' . kb_lang();
	return (string) get_theme_mod( $name, $d[ $name ] ?? '' );
}

add_action( 'customize_register', function ( $wp ) {
	$wp->add_section( 'kb_studio', array( 'title' => 'Studio details', 'priority' => 30 ) );
	$labels = array(
		'kb_phone'      => 'Phone',
		'kb_email'      => 'Email',
		'kb_address_en' => 'Address (English)',
		'kb_address_ru' => 'Address (Russian)',
		'kb_hours_en'   => 'Opening hours (English)',
		'kb_hours_ru'   => 'Opening hours (Russian)',
		'kb_note_en'    => 'Footer note (English)',
		'kb_note_ru'    => 'Footer note (Russian)',
	);
	foreach ( kb_studio_defaults() as $id => $default ) {
		$wp->add_setting( $id, array( 'default' => $default, 'sanitize_callback' => 'kb_email' === $id ? 'sanitize_email' : 'sanitize_text_field' ) );
		$wp->add_control( $id, array( 'label' => $labels[ $id ], 'section' => 'kb_studio', 'type' => 'text' ) );
	}
} );

/** [kb_contact] — address, phone, email and hours with icons, for the Contact page. */
add_shortcode( 'kb_contact', function () {
	$phone = kb_studio( 'phone' );
	$email = kb_studio( 'email' );
	$tel   = preg_replace( '/[^\d+]/', '', $phone );
	if ( $tel && '+' !== $tel[0] ) {
		$tel = ( 10 === strlen( $tel ) ? '+1' : '+' ) . $tel;
	}
	ob_start();
	?>
	<div class="kb-contact">
		<p class="kb-contact__row"><?php echo kb_icon( 'map-pin' ); // phpcs:ignore WordPress.Security.EscapeOutput -- own SVG ?><span><?php echo esc_html( kb_studio( 'address' ) ); ?></span></p>
		<?php if ( $phone ) : ?><p><a class="kb-contact__row kb-contact__link" href="tel:<?php echo esc_attr( $tel ); ?>"><?php echo kb_icon( 'phone' ); // phpcs:ignore ?><span><?php echo esc_html( $phone ); ?></span></a></p><?php endif; ?>
		<?php if ( $email ) : ?><p><a class="kb-contact__row kb-contact__link" href="mailto:<?php echo esc_attr( antispambot( $email ) ); ?>"><?php echo kb_icon( 'mail' ); // phpcs:ignore ?><span><?php echo esc_html( antispambot( $email ) ); ?></span></a></p><?php endif; ?>
		<p class="kb-contact__hours"><?php echo esc_html( kb_studio( 'hours' ) ); ?></p>
	</div>
	<?php
	return ob_get_clean();
} );
