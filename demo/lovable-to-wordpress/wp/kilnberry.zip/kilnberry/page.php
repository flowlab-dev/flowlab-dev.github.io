<?php
/** Every page: the blocks from the editor, full width; sections set their own width with block classes (see main.css). */
get_header();
?>
<main id="main" class="kb-main">
	<?php
	while ( have_posts() ) :
		the_post();
		the_content();
	endwhile;
	?>
</main>
<?php
get_footer();
