/* Kilnberry: day / night, phone menu, contact form. No libraries. */
(function () {
	var KB = window.KB || {};
	var root = document.documentElement;

	// day / night: the button shows the theme it switches to (as on the Lovable site)
	var themeBtn = document.querySelector('[data-kb-theme]');
	if (themeBtn) {
		var label = function () {
			themeBtn.setAttribute('aria-label', root.classList.contains('dark') ? KB.toDay : KB.toNight);
		};
		label();
		themeBtn.hidden = false;
		themeBtn.addEventListener('click', function () {
			var dark = !root.classList.contains('dark');
			root.classList.toggle('dark', dark);
			root.style.colorScheme = dark ? 'dark' : 'light';
			try { localStorage.setItem('kilnberry-theme', dark ? 'dark' : 'light'); } catch (e) {}
			label();
		});
	}

	// phone menu
	var burger = document.querySelector('[data-kb-menu]');
	var nav = document.getElementById('kb-nav');
	if (burger && nav) {
		var setOpen = function (open) {
			nav.classList.toggle('is-open', open);
			burger.setAttribute('aria-expanded', open ? 'true' : 'false');
			burger.setAttribute('aria-label', open ? KB.close : KB.menu);
		};
		burger.addEventListener('click', function () { setOpen(burger.getAttribute('aria-expanded') !== 'true'); });
		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' && burger.getAttribute('aria-expanded') === 'true') { setOpen(false); burger.focus(); }
		});
		nav.addEventListener('click', function (e) { if (e.target.closest('a')) setOpen(false); });
	}

	// contact form: errors next to each field, then sending without reloading the page
	var form = document.querySelector('[data-kb-form]');
	if (!form) return;
	form.noValidate = true; // our own messages next to the fields; without JavaScript the browser checks the fields
	var status = form.querySelector('.kb-form__status');
	var setError = function (name, text) {
		var input = form.elements[name];
		var box = document.getElementById('kb-e-' + name.replace('kb_', ''));
		if (!input || !box) return;
		input.setAttribute('aria-invalid', text ? 'true' : 'false');
		box.textContent = text || '';
		box.hidden = !text;
	};
	var check = function () {
		var bad = {};
		if (!form.elements.kb_name.value.trim()) bad.kb_name = KB.eName;
		if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.elements.kb_email.value.trim())) bad.kb_email = KB.eEmail;
		if (!form.elements.kb_msg.value.trim()) bad.kb_msg = KB.eMsg;
		['kb_name', 'kb_email', 'kb_msg'].forEach(function (n) { setError(n, bad[n]); });
		return bad;
	};
	['kb_name', 'kb_email', 'kb_msg'].forEach(function (n) {
		form.elements[n].addEventListener('blur', function () {
			if (form.elements[n].getAttribute('aria-invalid') === 'true') check();
		});
	});
	form.addEventListener('submit', function (e) {
		e.preventDefault();
		var bad = Object.keys(check());
		if (bad.length) { form.elements[bad[0]].focus(); return; }
		var btn = form.querySelector('button[type=submit]');
		var text = btn.textContent;
		btn.disabled = true;
		btn.textContent = KB.sending;
		status.textContent = '';
		fetch(form.getAttribute('action'), { // not form.action: the hidden field named «action» shadows it
			 method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' }, credentials: 'same-origin' })
			.then(function (r) { return r.json().catch(function () { return { ok: false, errors: {} }; }); })
			.then(function (res) {
				if (res.ok) {
					var done = document.createElement('div');
					done.className = 'kb-form__done';
					done.id = 'kb-form';
					done.setAttribute('role', 'status');
					done.tabIndex = -1;
					var p = document.createElement('p');
					p.textContent = form.dataset.ok;
					done.appendChild(p);
					form.replaceWith(done);
					done.focus();
					return;
				}
				var errs = res.errors || {};
				Object.keys(errs).forEach(function (k) { if (k !== 'form') setError(k, errs[k]); });
				status.textContent = errs.form || (Object.keys(errs).length ? '' : KB.eFail);
				btn.disabled = false;
				btn.textContent = text;
			})
			.catch(function () {
				status.textContent = KB.eFail;
				btn.disabled = false;
				btn.textContent = text;
			});
	});
})();
