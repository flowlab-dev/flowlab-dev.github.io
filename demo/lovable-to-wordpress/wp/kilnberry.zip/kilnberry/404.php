<?php
get_header();
?>
<main id="main" class="kb-main">
	<section class="site-container kb-intro kb-404">
		<p class="eyebrow">404</p>
		<h1><?php echo esc_html( kb_t( 'not_found' ) ); ?></h1>
		<p><a class="kb-btn" href="<?php echo esc_url( function_exists( 'pll_home_url' ) ? pll_home_url() : home_url( '/' ) ); ?>"><?php echo esc_html( kb_t( 'back_home' ) ); ?></a></p>
	</section>
</main>
<?php
get_footer();
